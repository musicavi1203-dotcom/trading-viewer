package com.example.tradingviewer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val pollMs = 15_000L
    private val symbolRe = Regex("^[A-Z.]{1,10}$")
    private val timeframes = listOf(
        "1Min" to "דקה",
        "5Min" to "5 דקות",
        "1Hour" to "שעה",
        "1Day" to "יום"
    )

    private lateinit var store: SecureStore
    private lateinit var watch: WatchStore
    private var client: AlpacaClient? = null
    private var stream: TradeStream? = null
    private var streamState = ""
    private var selected = ""
    private var timeframe = "1Min"
    private var lastSnapshots: Map<String, Snapshot> = emptyMap()
    private val tfButtons = mutableMapOf<String, Button>()

    private lateinit var watchList: LinearLayout
    private lateinit var addInput: EditText
    private lateinit var statusView: TextView
    private lateinit var marketView: TextView
    private lateinit var priceView: TextView
    private lateinit var statsView: TextView
    private lateinit var chart: ChartView
    private lateinit var signalView: TextView
    private lateinit var indicatorView: TextView
    private lateinit var alertInput: EditText
    private lateinit var alertsView: TextView

    private val poller = object : Runnable {
        override fun run() {
            ensureStream()
            refreshWatchlist()
            ui.postDelayed(this, pollMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SecureStore(this)
        watch = WatchStore(this)
        if (store.hasKeys()) showMain() else showSetup()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        stream?.close()
        io.shutdown()
        super.onDestroy()
    }

    // ---------- Helpers ----------

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(40, 40, 40, 40)
    }

    private fun heading(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 20f
        setTypeface(null, Typeface.BOLD)
        setPadding(0, 40, 0, 10)
    }

    private fun show(content: View) {
        setContentView(ScrollView(this).apply { addView(content) })
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun nowTime(): String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    // ---------- Setup (first launch) ----------

    private fun showSetup() {
        val box = column()

        val title = TextView(this).apply {
            text = "ברוך הבא ל-Trading Viewer"
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
        }
        val steps = TextView(this).apply {
            text = "כדי לקבל נתונים בזמן אמת צריך מפתח חינמי מ-Alpaca:\n\n" +
                "1. לחץ על הכפתור למטה והירשם (כמה דקות, פעם אחת בלבד).\n" +
                "2. בדשבורד עבור למצב Paper (חשבון דמו).\n" +
                "3. בכרטיס API Keys לחץ Generate New Keys.\n" +
                "4. העתק את שני הערכים והדבק אותם למטה.\n\n" +
                "המפתחות נשמרים מוצפנים בטלפון בלבד, והאפליקציה משתמשת בהם לקריאת נתונים בלבד."
            textSize = 16f
        }
        val openSignup = Button(this).apply {
            text = "פתח את דף ההרשמה של Alpaca"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://app.alpaca.markets/signup")))
            }
        }
        val idInput = EditText(this).apply {
            hint = "API Key ID"
            setSingleLine()
        }
        val secretInput = EditText(this).apply {
            hint = "Secret Key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val status = TextView(this)
        val check = Button(this)
        check.apply {
            text = "בדוק ושמור"
            setOnClickListener {
                val id = idInput.text.toString().trim()
                val secret = secretInput.text.toString().trim()
                if (id.isEmpty() || secret.isEmpty()) {
                    toast("יש למלא את שני השדות")
                    return@setOnClickListener
                }
                check.isEnabled = false
                status.text = "בודק את המפתחות..."
                io.execute {
                    val error: String? = try {
                        // SPY is a cheap, always-listed test symbol. A bad key fails here.
                        AlpacaClient(id, secret).fetchSnapshots(listOf("SPY"))
                        null
                    } catch (e: Exception) {
                        e.message ?: "שגיאה לא ידועה"
                    }
                    ui.post {
                        if (error == null) {
                            store.saveKeys(id, secret)
                            recreate()
                        } else {
                            check.isEnabled = true
                            status.text = "המפתחות לא עובדים ($error). בדוק שהעתקת נכון."
                        }
                    }
                }
            }
        }

        box.addView(title)
        box.addView(steps)
        box.addView(openSignup)
        box.addView(idInput)
        box.addView(secretInput)
        box.addView(check)
        box.addView(status)
        show(box)
    }

    // ---------- Main screen ----------

    private fun showMain() {
        val c = AlpacaClient(store.keyId()!!, store.keySecret()!!)
        client = c
        stream = TradeStream(store.keyId()!!, store.keySecret()!!)
        Notifier.createChannel(this)
        askNotificationPermission()
        selected = watch.symbols().firstOrNull() ?: ""

        val box = column()

        box.addView(heading("רשימת מעקב"))
        watchList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(watchList)
        addInput = EditText(this).apply {
            hint = "הוסף סמל, למשל TSLA"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        box.addView(addInput)
        box.addView(Button(this).apply {
            text = "הוסף לרשימה"
            setOnClickListener {
                addSymbol(addInput.text.toString())
                addInput.setText("")
            }
        })
        box.addView(TextView(this).apply {
            text = "לחיצה על מניה בוחרת אותה. לחיצה ארוכה מסירה אותה מהרשימה."
            textSize = 13f
        })

        marketView = TextView(this)
        statusView = TextView(this)
        box.addView(marketView)
        box.addView(statusView)

        priceView = TextView(this).apply { textSize = 28f }
        statsView = TextView(this).apply { textSize = 14f }
        box.addView(priceView)
        box.addView(statsView)

        val tfRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        timeframes.forEach { (code, label) ->
            val b = Button(this).apply {
                text = label
                setOnClickListener { setTimeframe(code) }
            }
            tfButtons[code] = b
            tfRow.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        box.addView(tfRow)

        chart = ChartView(this)
        box.addView(chart, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 500))

        signalView = TextView(this).apply {
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
        }
        indicatorView = TextView(this)
        box.addView(signalView)
        box.addView(indicatorView)

        box.addView(heading("התראות מחיר"))
        alertInput = EditText(this).apply {
            hint = "מחיר, למשל 150.50"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        box.addView(alertInput)

        val alertRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        alertRow.addView(
            Button(this).apply {
                text = "מעל המחיר"
                setOnClickListener { addAlert(true) }
            },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        alertRow.addView(
            Button(this).apply {
                text = "מתחת למחיר"
                setOnClickListener { addAlert(false) }
            },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        box.addView(alertRow)

        alertsView = TextView(this)
        box.addView(alertsView)
        box.addView(Button(this).apply {
            text = "מחק התראות של המניה הנבחרת"
            setOnClickListener {
                watch.removeAlerts(selected)
                refreshAlertsView()
            }
        })

        box.addView(heading("פעולות"))
        box.addView(Button(this).apply {
            text = "רענן עכשיו"
            setOnClickListener {
                refreshWatchlist()
                loadDetail()
            }
        })
        box.addView(Button(this).apply {
            text = "מחק מפתחות מהטלפון"
            setOnClickListener {
                stream?.close()
                store.clear()
                recreate()
            }
        })

        show(box)

        renderWatchlist()
        renderStats()
        updateTfButtons()
        refreshAlertsView()
        loadDetail()
        ui.post(poller)
    }

    // ---------- Watchlist ----------

    private fun addSymbol(raw: String) {
        val sym = raw.trim().uppercase()
        if (!symbolRe.matches(sym)) {
            toast("סמל לא תקין")
            return
        }
        watch.add(sym)
        renderWatchlist()
        select(sym)
        refreshWatchlist()
    }

    private fun select(sym: String) {
        selected = sym
        renderWatchlist()
        loadDetail()
    }

    private fun renderWatchlist() {
        if (!::watchList.isInitialized) return
        watchList.removeAllViews()
        for (sym in watch.symbols()) {
            val snap = lastSnapshots[sym]
            val pct = snap?.changePct() ?: Double.NaN
            val line = if (snap == null || snap.last.isNaN()) {
                "$sym   —"
            } else if (pct.isNaN()) {
                "$sym   %.2f".format(snap.last)
            } else {
                "$sym   %.2f   (%+.2f%%)".format(snap.last, pct)
            }
            val row = TextView(this).apply {
                text = line
                textSize = 18f
                setPadding(20, 20, 20, 20)
                setTypeface(null, if (sym == selected) Typeface.BOLD else Typeface.NORMAL)
                setBackgroundColor(if (sym == selected) Color.parseColor("#E3F2FD") else Color.TRANSPARENT)
                if (!pct.isNaN()) {
                    setTextColor(if (pct >= 0) Color.parseColor("#2E7D32") else Color.parseColor("#C62828"))
                }
                setOnClickListener { select(sym) }
                setOnLongClickListener {
                    watch.remove(sym)
                    if (selected == sym) selected = watch.symbols().firstOrNull() ?: ""
                    renderWatchlist()
                    loadDetail()
                    true
                }
            }
            watchList.addView(row)
        }
    }

    private fun renderStats() {
        if (!::statsView.isInitialized) return
        val s = lastSnapshots[selected]
        statsView.text = if (s == null) {
            ""
        } else {
            "פתיחה: %.2f | גבוה: %.2f | נמוך: %.2f\nנפח יומי: %,.0f | סגירה קודמת: %.2f | שינוי: %+.2f%%"
                .format(s.open, s.high, s.low, s.volume, s.prevClose, s.changePct())
        }
    }

    private fun refreshAlertsView() {
        if (!::alertsView.isInitialized) return
        val list = watch.alertsFor(selected)
        alertsView.text = if (list.isEmpty()) {
            "אין התראות למניה הנבחרת"
        } else {
            list.joinToString("\n") { a ->
                (if (a.above) "מעל " else "מתחת ל-") + "%.2f".format(a.price)
            }
        }
    }

    private fun addAlert(above: Boolean) {
        val price = alertInput.text.toString().trim().toDoubleOrNull()
        if (selected.isEmpty() || price == null || price <= 0.0) {
            toast("בחר מניה והזן מחיר תקין")
            return
        }
        watch.addAlert(Alert(selected, above, price))
        alertInput.setText("")
        refreshAlertsView()
        toast("ההתראה נשמרה")
    }

    // ---------- Timeframe and detail ----------

    private fun setTimeframe(code: String) {
        timeframe = code
        updateTfButtons()
        loadDetail()
    }

    private fun updateTfButtons() {
        tfButtons.forEach { (code, b) -> b.isEnabled = code != timeframe }
    }

    private fun rsiLabel(rsi: Double?): String = when {
        rsi == null -> ""
        rsi >= 70 -> "קנוי יתר (מעל 70)"
        rsi <= 30 -> "נמכר יתר (מתחת ל-30)"
        else -> "אזור נייטרלי"
    }

    private fun loadDetail() {
        val c = client ?: return
        val sym = selected
        if (sym.isEmpty()) {
            chart.setData(emptyList(), emptyList())
            signalView.text = ""
            indicatorView.text = "הוסף מניה לרשימה כדי להתחיל"
            return
        }
        renderStats()
        refreshAlertsView()

        // Same connection, just switch the subscribed symbol.
        stream?.setSymbol(sym)

        val tf = timeframe
        io.execute {
            try {
                val closes = c.fetchBars(sym, tf, 120).map { it.c }
                val rsi = Indicators.rsi(closes)
                val (headline, why) = Signal.evaluate(closes)
                val lines = listOf(Indicators.smaSeries(closes, 5), Indicators.smaSeries(closes, 20))
                ui.post {
                    // Ignore results that arrived after the user switched symbol or timeframe.
                    if (sym == selected && tf == timeframe) {
                        chart.setData(closes, lines)
                        signalView.text = headline
                        val rsiText = rsi?.let { "%.1f".format(it) } ?: "אין מספיק נתונים"
                        indicatorView.text = "RSI(14): $rsiText  ${rsiLabel(rsi)}\n\n" +
                            why + "\n\nזה כלל טכני פשוט ולא ייעוץ השקעות."
                    }
                }
            } catch (e: Exception) {
                ui.post { statusView.text = "שגיאה בטעינת נתונים: ${e.message}" }
            }
        }
    }

    // ---------- Live stream (one connection, reconnects on each poll) ----------

    private fun ensureStream() {
        stream?.ensureConnected(
            onPrice = { sym, p ->
                ui.post { if (sym == selected) priceView.text = "$sym   %.2f".format(p) }
            },
            onStatus = { s ->
                ui.post {
                    streamState = s
                    statusView.text = "זרם: $s"
                }
            }
        )
    }

    // ---------- Polling (watchlist, clock, alerts) ----------

    private fun refreshWatchlist() {
        val c = client ?: return
        val symbols = watch.symbols()
        if (symbols.isEmpty()) {
            lastSnapshots = emptyMap()
            renderWatchlist()
            return
        }
        io.execute {
            try {
                val snaps = c.fetchSnapshots(symbols)
                val clock = c.fetchClock()
                val fired = watch.takeTriggered(snaps)
                ui.post {
                    lastSnapshots = snaps
                    renderWatchlist()
                    renderStats()
                    marketView.text = clock
                    statusView.text = "עודכן ב-${nowTime()} | זרם: $streamState"
                    fired.forEach { a ->
                        val text = "${a.symbol} " +
                            (if (a.above) "עבר מעל " else "ירד מתחת ל-") + "%.2f".format(a.price)
                        Notifier.show(this, text)
                    }
                    refreshAlertsView()
                }
            } catch (e: Exception) {
                ui.post { statusView.text = "שגיאה בעדכון: ${e.message}" }
            }
        }
    }
}
