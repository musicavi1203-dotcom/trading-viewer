package com.example.tradingviewer

/**
 * A simple, transparent rule: moving-average crossover (fast 5 vs slow 20).
 * It is a rule output, not a prediction or investment advice.
 */
object Signal {

    /** Returns (headline, explanation). Works on whichever bars are displayed. */
    fun evaluate(closes: List<Double>): Pair<String, String> {
        val fast = Indicators.smaSeries(closes, 5)
        val slow = Indicators.smaSeries(closes, 20)
        val last = closes.lastIndex
        if (last < 1) return "אין מספיק נתונים" to "צריך לפחות 21 נרות כדי לחשב את הכלל."

        val fastNow = fast[last]
        val slowNow = slow[last]
        val fastPrev = fast[last - 1]
        val slowPrev = slow[last - 1]
        if (fastNow == null || slowNow == null || fastPrev == null || slowPrev == null) {
            return "אין מספיק נתונים" to "צריך לפחות 21 נרות כדי לחשב את הכלל."
        }

        val numbers = "ממוצע קצר (5): %.2f | ממוצע ארוך (20): %.2f".format(fastNow, slowNow)

        return when {
            fastPrev <= slowPrev && fastNow > slowNow ->
                "אות קנייה לפי הכלל" to "הממוצע הקצר חצה כלפי מעלה את הארוך.\n$numbers"
            fastPrev >= slowPrev && fastNow < slowNow ->
                "אות מכירה לפי הכלל" to "הממוצע הקצר חצה כלפי מטה את הארוך.\n$numbers"
            fastNow > slowNow ->
                "מגמה עולה, אין אות חדש" to "הממוצע הקצר מעל הארוך.\n$numbers"
            else ->
                "מגמה יורדת, אין אות חדש" to "הממוצע הקצר מתחת לארוך.\n$numbers"
        }
    }
}
