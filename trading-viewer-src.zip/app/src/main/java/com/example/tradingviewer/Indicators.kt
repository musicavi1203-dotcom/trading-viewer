package com.example.tradingviewer

/** Standard technical indicators. Pure functions, no Android dependencies. */
object Indicators {

    /** Simple moving average aligned with the input. Null until enough values exist. */
    fun smaSeries(values: List<Double>, period: Int): List<Double?> =
        values.indices.map { i ->
            if (i + 1 < period) null
            else values.subList(i - period + 1, i + 1).average()
        }

    /** Relative Strength Index (Wilder smoothing). Null when there is not enough data. */
    fun rsi(values: List<Double>, period: Int = 14): Double? {
        if (values.size <= period) return null
        var gain = 0.0
        var loss = 0.0
        for (i in 1..period) {
            val d = values[i] - values[i - 1]
            if (d > 0) gain += d else loss -= d
        }
        var avgGain = gain / period
        var avgLoss = loss / period
        for (i in period + 1 until values.size) {
            val d = values[i] - values[i - 1]
            val g = if (d > 0) d else 0.0
            val l = if (d < 0) -d else 0.0
            avgGain = (avgGain * (period - 1) + g) / period
            avgLoss = (avgLoss * (period - 1) + l) / period
        }
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - 100.0 / (1.0 + rs)
    }
}
