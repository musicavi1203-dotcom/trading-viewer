package com.example.tradingviewer

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

/**
 * Stores the Alpaca keys encrypted on the device.
 * The master key lives in the Android Keystore, so other apps cannot read it.
 */
class SecureStore(context: Context) {

    private val prefs = EncryptedSharedPreferences.create(
        "secure_prefs",
        MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),
        context,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveKeys(id: String, secret: String) {
        prefs.edit()
            .putString("key_id", id)
            .putString("key_secret", secret)
            .apply()
    }

    fun keyId(): String? = prefs.getString("key_id", null)

    fun keySecret(): String? = prefs.getString("key_secret", null)

    fun hasKeys(): Boolean =
        !keyId().isNullOrBlank() && !keySecret().isNullOrBlank()

    fun clear() {
        prefs.edit().clear().apply()
    }
}
