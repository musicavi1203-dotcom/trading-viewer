package com.example.tradingviewer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

/** Line chart of prices with optional moving-average overlays. */
class ChartView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private var price: List<Double> = emptyList()
    private var overlays: List<List<Double?>> = emptyList()

    private val pricePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1565C0")
        strokeWidth = 4f
        style = Paint.Style.STROKE
    }

    private val overlayColors = listOf(Color.parseColor("#FB8C00"), Color.parseColor("#8E24AA"))

    private val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 3f
        style = Paint.Style.STROKE
    }

    fun setData(prices: List<Double>, lines: List<List<Double?>>) {
        price = prices
        overlays = lines
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (price.size < 2) return

        val all = price + overlays.flatMap { line -> line.filterNotNull() }
        val lo = all.min()
        val hi = all.max()
        val range = (hi - lo).takeIf { it > 0.0 } ?: 1.0
        val pad = 16f
        val w = width - 2 * pad
        val h = height - 2 * pad
        val n = price.size

        fun yOf(v: Double): Float = pad + h * (1f - ((v - lo) / range).toFloat())

        val path = Path()
        price.forEachIndexed { i, v ->
            val x = pad + i * w / (n - 1)
            val y = yOf(v)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, pricePaint)

        overlays.forEachIndexed { k, line ->
            overlayPaint.color = overlayColors[k % overlayColors.size]
            val p = Path()
            var started = false
            line.forEachIndexed { i, v ->
                if (v == null) {
                    started = false
                } else {
                    val x = pad + i * w / (n - 1)
                    val y = yOf(v)
                    if (!started) {
                        p.moveTo(x, y)
                        started = true
                    } else {
                        p.lineTo(x, y)
                    }
                }
            }
            canvas.drawPath(p, overlayPaint)
        }
    }
}
