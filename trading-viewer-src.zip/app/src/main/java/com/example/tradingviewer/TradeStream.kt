package com.example.tradingviewer

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Live trades over one WebSocket for the whole app.
 *
 * The free IEX plan allows only ONE connection per key (a second one gets error 406),
 * so symbol changes use subscribe and unsubscribe on the same socket.
 */
class TradeStream(
    private val keyId: String,
    private val secret: String
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var socket: WebSocket? = null
    private var authed = false
    private var current: String? = null
    private var onPrice: (String, Double) -> Unit = { _, _ -> }
    private var onStatus: (String) -> Unit = {}

    /** Opens the connection if it is not open. Safe to call often. */
    @Synchronized
    fun ensureConnected(onPrice: (String, Double) -> Unit, onStatus: (String) -> Unit) {
        this.onPrice = onPrice
        this.onStatus = onStatus
        if (socket != null) return
        authed = false
        val request = Request.Builder()
            .url("wss://stream.data.alpaca.markets/v2/iex")
            .build()
        socket = http.newWebSocket(request, listener)
    }

    /** Switches the live symbol on the existing connection. */
    @Synchronized
    fun setSymbol(symbol: String) {
        val old = current
        if (old == symbol) return
        current = symbol
        if (authed) {
            if (old != null) send(channelMessage("unsubscribe", old))
            send(channelMessage("subscribe", symbol))
        }
    }

    @Synchronized
    fun close() {
        socket?.close(1000, null)
        socket = null
        authed = false
        current = null
    }

    private fun channelMessage(action: String, symbol: String): String =
        JSONObject()
            .put("action", action)
            .put("trades", JSONArray().put(symbol))
            .toString()

    private fun send(text: String) {
        socket?.send(text)
    }

    private val listener = object : WebSocketListener() {

        override fun onOpen(webSocket: WebSocket, response: Response) {
            val auth = JSONObject()
                .put("action", "auth")
                .put("key", keyId)
                .put("secret", secret)
            webSocket.send(auth.toString())
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            val messages = JSONArray(text)
            for (i in 0 until messages.length()) {
                val m = messages.getJSONObject(i)
                when (m.optString("T")) {
                    "success" -> {
                        val msg = m.optString("msg")
                        onStatus(msg)
                        if (msg == "authenticated") {
                            synchronized(this@TradeStream) {
                                authed = true
                                current?.let { send(channelMessage("subscribe", it)) }
                            }
                        }
                    }
                    "error" -> {
                        val code = m.optInt("code")
                        val hint = if (code == 406) {
                            " (החיבור פתוח כבר במקום אחר. סגור אפליקציה או מסך אחר שמשתמשים באותו מפתח)"
                        } else ""
                        onStatus("שגיאה מהשרת $code: ${m.optString("msg")}$hint")
                    }
                    "t" -> onPrice(m.optString("S"), m.getDouble("p"))
                }
            }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            synchronized(this@TradeStream) {
                socket = null
                authed = false
            }
            onStatus("החיבור נכשל: ${t.message}. ינסה להתחבר מחדש.")
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            synchronized(this@TradeStream) {
                socket = null
                authed = false
            }
            onStatus("החיבור נסגר")
        }
    }
}
