package com.example.tradingviewer

import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.util.concurrent.TimeUnit

data class Bar(
    val t: String,
    val o: Double,
    val h: Double,
    val l: Double,
    val c: Double,
    val v: Double
)

/** Latest market state for one symbol. Missing values are NaN. */
data class Snapshot(
    val last: Double,
    val prevClose: Double,
    val open: Double,
    val high: Double,
    val low: Double,
    val volume: Double
) {
    fun changePct(): Double =
        if (prevClose > 0 && !last.isNaN()) (last - prevClose) / prevClose * 100 else Double.NaN
}

/**
 * Read-only REST access to Alpaca: bars, snapshots and the market clock.
 * Trading endpoints are intentionally not implemented.
 */
class AlpacaClient(private val keyId: String, private val secret: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun get(url: HttpUrl): String {
        val request = Request.Builder()
            .url(url)
            .header("APCA-API-KEY-ID", keyId)
            .header("APCA-API-SECRET-KEY", secret)
            .build()
        http.newCall(request).execute().use { response: Response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("קוד תגובה ${response.code}")
            }
            return response.body?.string() ?: "{}"
        }
    }

    /**
     * Most recent bars, oldest first.
     * timeframe: 1Min, 5Min, 1Hour or 1Day.
     * The start date is set so the newest bars are returned, not stale ones.
     */
    fun fetchBars(symbol: String, timeframe: String, limit: Int): List<Bar> {
        val lookback = when (timeframe) {
            "1Min" -> Duration.ofDays(5)
            "5Min" -> Duration.ofDays(30)
            "1Hour" -> Duration.ofDays(120)
            else -> Duration.ofDays(400)
        }
        val url = "https://data.alpaca.markets/v2/stocks/$symbol/bars".toHttpUrl().newBuilder()
            .addQueryParameter("timeframe", timeframe)
            .addQueryParameter("start", Instant.now().minus(lookback).toString())
            .addQueryParameter("limit", limit.toString())
            .addQueryParameter("sort", "desc")
            .addQueryParameter("feed", "iex")
            .build()
        val arr = JSONObject(get(url)).optJSONArray("bars") ?: return emptyList()
        val bars = (0 until arr.length()).map { i ->
            val b = arr.getJSONObject(i)
            Bar(
                t = b.optString("t"),
                o = b.getDouble("o"),
                h = b.getDouble("h"),
                l = b.getDouble("l"),
                c = b.getDouble("c"),
                v = b.getDouble("v")
            )
        }
        // Requested newest first, so reverse to get chronological order for the chart.
        return bars.reversed()
    }

    /** Latest trade, daily bar and previous close for many symbols in one request. */
    fun fetchSnapshots(symbols: List<String>): Map<String, Snapshot> {
        val url = "https://data.alpaca.markets/v2/stocks/snapshots".toHttpUrl().newBuilder()
            .addQueryParameter("symbols", symbols.joinToString(","))
            .addQueryParameter("feed", "iex")
            .build()
        val root = JSONObject(get(url))
        val out = mutableMapOf<String, Snapshot>()
        root.keys().forEach { sym ->
            val s = root.optJSONObject(sym) ?: return@forEach
            val trade = s.optJSONObject("latestTrade")
            val daily = s.optJSONObject("dailyBar")
            val prev = s.optJSONObject("prevDailyBar")
            out[sym] = Snapshot(
                last = trade?.optDouble("p", Double.NaN) ?: Double.NaN,
                prevClose = prev?.optDouble("c", Double.NaN) ?: Double.NaN,
                open = daily?.optDouble("o", Double.NaN) ?: Double.NaN,
                high = daily?.optDouble("h", Double.NaN) ?: Double.NaN,
                low = daily?.optDouble("l", Double.NaN) ?: Double.NaN,
                volume = daily?.optDouble("v", Double.NaN) ?: Double.NaN
            )
        }
        return out
    }

    /** Whether the US market is open now, and when it next opens if closed. */
    fun fetchClock(): String {
        val root = JSONObject(get("https://paper-api.alpaca.markets/v2/clock".toHttpUrl()))
        return if (root.optBoolean("is_open")) {
            "השוק פתוח"
        } else {
            "השוק סגור. נפתח ב-" + root.optString("next_open").take(16).replace('T', ' ')
        }
    }
}
