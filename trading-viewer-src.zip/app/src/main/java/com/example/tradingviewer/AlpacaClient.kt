package com.example.tradingviewer

import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class Bar(
    val t: String,
    val o: Double,
    val h: Double,
    val l: Double,
    val c: Double,
    val v: Double
)

/** Latest market state for one symbol. Missing values are NaN. */
data class Snapshot(
    val last: Double,
    val prevClose: Double,
    val open: Double,
    val high: Double,
    val low: Double,
    val volume: Double
) {
    fun changePct(): Double =
        if (prevClose > 0 && !last.isNaN()) (last - prevClose) / prevClose * 100 else Double.NaN
}

/**
 * Read-only access to Alpaca. Only market data and the clock are used.
 * Trading endpoints are intentionally not implemented.
 */
class AlpacaClient(private val keyId: String, private val secret: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun get(url: HttpUrl): String {
        val request = Request.Builder()
            .url(url)
            .header("APCA-API-KEY-ID", keyId)
            .header("APCA-API-SECRET-KEY", secret)
            .build()
        http.newCall(request).execute().use { response: Response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("קוד תגובה ${response.code}")
            }
            return response.body?.string() ?: "{}"
        }
    }

    /** OHLCV bars, oldest first. timeframe examples: 1Min, 5Min, 1Hour, 1Day. */
    fun fetchBars(symbol: String, timeframe: String, limit: Int): List<Bar> {
        val url = "https://data.alpaca.markets/v2/stocks/$symbol/bars".toHttpUrl().newBuilder()
            .addQueryParameter("timeframe", timeframe)
            .addQueryParameter("limit", limit.toString())
            .addQueryParameter("feed", "iex")
            .build()
        val arr: JSONArray = JSONObject(get(url)).optJSONArray("bars") ?: return emptyList()
        return (0 until arr.length()).map { i ->
            val b = arr.getJSONObject(i)
            Bar(
                t = b.optString("t"),
                o = b.getDouble("o"),
                h = b.getDouble("h"),
                l = b.getDouble("l"),
                c = b.getDouble("c"),
                v = b.getDouble("v")
            )
        }
    }

    /** One request for many symbols. */
    fun fetchSnapshots(symbols: List<String>): Map<String, Snapshot> {
        val url = "https://data.alpaca.markets/v2/stocks/snapshots".toHttpUrl().newBuilder()
            .addQueryParameter("symbols", symbols.joinToString(","))
            .addQueryParameter("feed", "iex")
            .build()
        val root = JSONObject(get(url))
        val out = mutableMapOf<String, Snapshot>()
        root.keys().forEach { sym ->
            val s = root.optJSONObject(sym) ?: return@forEach
            val trade = s.optJSONObject("latestTrade")
            val daily = s.optJSONObject("dailyBar")
            val prev = s.optJSONObject("prevDailyBar")
            out[sym] = Snapshot(
                last = trade?.optDouble("p", Double.NaN) ?: Double.NaN,
                prevClose = prev?.optDouble("c", Double.NaN) ?: Double.NaN,
                open = daily?.optDouble("o", Double.NaN) ?: Double.NaN,
                high = daily?.optDouble("h", Double.NaN) ?: Double.NaN,
                low = daily?.optDouble("l", Double.NaN) ?: Double.NaN,
                volume = daily?.optDouble("v", Double.NaN) ?: Double.NaN
            )
        }
        return out
    }

    /** Whether the US market is open right now, and when it next opens if closed. */
    fun fetchClock(): String {
        val root = JSONObject(get("https://paper-api.alpaca.markets/v2/clock".toHttpUrl()))
        return if (root.optBoolean("is_open")) {
            "השוק פתוח"
        } else {
            "השוק סגור. נפתח ב-" + root.optString("next_open").take(16).replace('T', ' ')
        }
    }

    /** Live trades for one symbol. The caller closes the returned socket. */
    fun openTradeStream(
        symbol: String,
        onPrice: (Double) -> Unit,
        onStatus: (String) -> Unit
    ): WebSocket {
        val request = Request.Builder()
            .url("wss://stream.alpaca.markets/v2/iex")
            .build()

        return http.newWebSocket(request, object : WebSocketListener() {

            override fun onOpen(webSocket: WebSocket, response: Response) {
                val auth = JSONObject()
                    .put("action", "auth")
                    .put("key", keyId)
                    .put("secret", secret)
                webSocket.send(auth.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val messages = JSONArray(text)
                for (i in 0 until messages.length()) {
                    val m = messages.getJSONObject(i)
                    when (m.optString("T")) {
                        "success" -> {
                            val msg = m.optString("msg")
                            onStatus(msg)
                            if (msg == "authenticated") {
                                val sub = JSONObject()
                                    .put("action", "subscribe")
                                    .put("trades", JSONArray().put(symbol))
                                webSocket.send(sub.toString())
                            }
                        }
                        "error" -> onStatus("שגיאה מהשרת: ${m.optString("msg")}")
                        "t" -> onPrice(m.getDouble("p"))
                    }
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                onStatus("החיבור נכשל: ${t.message}")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                onStatus("החיבור נסגר")
            }
        })
    }
}
