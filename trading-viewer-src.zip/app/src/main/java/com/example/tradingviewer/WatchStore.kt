package com.example.tradingviewer

import android.content.Context

/** A price alert. above = true means "fire when price rises to or past price". */
data class Alert(val symbol: String, val above: Boolean, val price: Double)

/**
 * Watchlist and alerts. Not secret, so plain SharedPreferences is used.
 * API keys are never stored here.
 */
class WatchStore(context: Context) {

    private val prefs = context.getSharedPreferences("watch", Context.MODE_PRIVATE)

    fun symbols(): List<String> {
        if (!prefs.contains("symbols")) return listOf("NVDA", "AAPL", "SPY")
        return (prefs.getString("symbols", "") ?: "").split(",").filter { it.isNotBlank() }
    }

    private fun saveSymbols(list: List<String>) {
        prefs.edit().putString("symbols", list.joinToString(",")).apply()
    }

    fun add(symbol: String) {
        val list = symbols()
        if (symbol !in list) saveSymbols(list + symbol)
    }

    fun remove(symbol: String) {
        saveSymbols(symbols().filter { it != symbol })
        removeAlerts(symbol)
    }

    private fun allAlerts(): List<Alert> =
        (prefs.getString("alerts", "") ?: "").split(";").filter { it.isNotBlank() }.mapNotNull { entry ->
            val parts = entry.split("|")
            if (parts.size != 3) return@mapNotNull null
            val price = parts[2].toDoubleOrNull() ?: return@mapNotNull null
            Alert(parts[0], parts[1] == "A", price)
        }

    private fun saveAlerts(list: List<Alert>) {
        val text = list.joinToString(";") { a ->
            "${a.symbol}|${if (a.above) "A" else "B"}|${a.price}"
        }
        prefs.edit().putString("alerts", text).apply()
    }

    fun alertsFor(symbol: String): List<Alert> = allAlerts().filter { it.symbol == symbol }

    fun addAlert(alert: Alert) = saveAlerts(allAlerts() + alert)

    fun removeAlerts(symbol: String) = saveAlerts(allAlerts().filter { it.symbol != symbol })

    /** Returns alerts whose condition is now met, and removes them so they fire once. */
    fun takeTriggered(snapshots: Map<String, Snapshot>): List<Alert> {
        val all = allAlerts()
        val fired = all.filter { a ->
            val last = snapshots[a.symbol]?.last ?: Double.NaN
            if (last.isNaN()) false
            else if (a.above) last >= a.price
            else last <= a.price
        }
        if (fired.isNotEmpty()) saveAlerts(all - fired.toSet())
        return fired
    }
}
